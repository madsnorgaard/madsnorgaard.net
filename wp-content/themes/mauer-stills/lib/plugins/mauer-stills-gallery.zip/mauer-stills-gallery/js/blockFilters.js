wp.hooks.addFilter(
	'blocks.registerBlockType',
	'mauer-stills/gallery',
	function( settings, name ) {
		if (name === 'mauer-stills/gallery') {
			return lodash.assign({}, settings, {
				supports: lodash.assign({}, settings.supports, {
					align: false,
				}),
			});
		}
		return settings;
	}
);
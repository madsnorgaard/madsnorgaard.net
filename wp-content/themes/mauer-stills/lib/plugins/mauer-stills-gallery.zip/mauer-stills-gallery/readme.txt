
This plugin was created using the 'Create Guten Block' library developed by Ahmad Awais.
https://github.com/ahmadawais/create-guten-block

If you would like to alter the block (contained in the 'src' folder), please run 'npm install' in the plugin folder, and then 'npm start'.